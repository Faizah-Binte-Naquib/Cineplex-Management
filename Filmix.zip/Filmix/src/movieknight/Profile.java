/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package movieknight;

import java.util.ArrayList;

/**
 *
 * @author User
 */
public class Profile {

    private String name, userID, password;
    private int age;
    private String gender;
    ArrayList<Ticket> ticketsBought = new ArrayList();

    public Profile() {
    }

    public Profile(String name, String userID, String password, int age, String gender) {
        this.name = name;
        this.userID = userID;
        this.password = password;
        this.age = age;
        this.gender = gender;
    }

    void purchaseInfo(Movie watchedMovie, Ticket purchased) {

    }

}
