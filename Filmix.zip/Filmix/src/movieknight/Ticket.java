/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package movieknight;

/**
 *
 * @author User
 */
public class Ticket {

    String seatNumber, theaterName, time;
    int price;
    String category;

    public Ticket(String seatNumber, String theaterName, String time) {
        this.seatNumber = seatNumber;
        this.theaterName = theaterName;
        this.time = time;
    }

    double getPrices(int quantity) {
        if (category.equals("premium")) {
            return 250 * quantity;
        } else {
            return 200 * quantity;
        }
    }

}
